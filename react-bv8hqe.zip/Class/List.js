import React from "react";

export const List = (props) => {
  const title =props.title;
  return (
    <div>
     <h4>{ title }</h4>
    <s>ここにピックアップをきちんと差し込む</s>
    </div>
  )
}