import React from 'react';
import './style.css';
import { List } from '../Class/List ';
import { useState } from "./react";



export default function App() {

  return (
    <div>
      <h1>Holoholo</h1>

      
      <p>会員登録してみる</p>
      
      <List title="ピックアップ" />
      <List title="クリエイター"/>

      <h2>Holoholoとは</h2>
      <p>Holoholoは～会社です。</p>

      <h3>Holoholoについて</h3>

    </div>
  );
}


export default App;